package com.example.viewmodel

import android.annotation.SuppressLint
import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.connectivity.Esp32ConnectionManager
import com.example.export.CsvExportManager
import com.example.model.ConnectionType
import com.example.model.DeviceLinkStatus
import com.example.model.GpsData
import com.example.model.ImuData
import com.example.model.IncidentEvent
import com.example.model.IncidentType
import com.example.model.RiderProfile
import com.example.sensor.PhoneSensorEngine
import com.example.sync.Esp32SyncEngine
import com.example.sync.Esp32SyncStatus
import com.example.sync.SyncTransport
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class RamsViewModel(application: Application) : AndroidViewModel(application) {

  // Phone Physical Hardware Sensors
  val phoneSensorEngine = PhoneSensorEngine(application.applicationContext, viewModelScope)

  // Wearable Sync & Emergency Uplink Engine (WebSocket / TCP / Bluetooth Classic & BLE)
  val esp32SyncEngine = Esp32SyncEngine(viewModelScope, application.applicationContext)

  // Internal Fallback manager
  private val simulatedConnectionManager = Esp32ConnectionManager(viewModelScope)

  // CSV Logger & Exporter
  val csvExportManager = CsvExportManager(application.applicationContext)

  // Rider Profile & Registration State (Persisted in SharedPreferences)
  private val _riderProfile = MutableStateFlow(RiderProfile.loadFromPreferences(application.applicationContext))
  val riderProfile: StateFlow<RiderProfile> = _riderProfile.asStateFlow()

  // Nearby Incidents on Map toggle (Default: OFF / false)
  val showNearbyIncidents: StateFlow<Boolean> = _riderProfile.map { it.showNearbyIncidents }
    .stateIn(viewModelScope, SharingStarted.Eagerly, false)

  // Use real phone sensors by default
  private val _usePhoneSensors = MutableStateFlow(true)
  val usePhoneSensors: StateFlow<Boolean> = _usePhoneSensors.asStateFlow()

  // Dynamic active sensor states (Phone Hardware)
  val gpsState: StateFlow<GpsData> = combine(
    _usePhoneSensors,
    phoneSensorEngine.phoneGpsState,
    simulatedConnectionManager.gpsState
  ) { usePhone, phoneGps, simGps ->
    if (usePhone) phoneGps else simGps
  }.stateIn(viewModelScope, SharingStarted.Eagerly, phoneSensorEngine.phoneGpsState.value)

  val imuState: StateFlow<ImuData> = combine(
    _usePhoneSensors,
    phoneSensorEngine.phoneImuState,
    simulatedConnectionManager.imuState
  ) { usePhone, phoneImu, simImu ->
    if (usePhone) phoneImu else simImu
  }.stateIn(viewModelScope, SharingStarted.Eagerly, phoneSensorEngine.phoneImuState.value)

  val linkStatus: StateFlow<DeviceLinkStatus> = combine(
    _usePhoneSensors,
    esp32SyncEngine.syncStatus,
    simulatedConnectionManager.linkStatus,
    _riderProfile
  ) { usePhone, sync, simLink, profile ->
    if (usePhone) {
      val connType = when (sync.transport) {
        SyncTransport.WEBSOCKET -> ConnectionType.WEBSOCKET
        SyncTransport.WIFI_TCP -> ConnectionType.WIFI_SOCKET
        SyncTransport.BLUETOOTH_SPP -> ConnectionType.BLUETOOTH_SPP
        SyncTransport.STANDALONE_LOGGER -> ConnectionType.SIMULATION
      }
      DeviceLinkStatus(
        isConnected = sync.isSyncActive,
        connectionType = connType,
        pingLatencyMs = 8L,
        packetRateHz = sync.syncRateHz,
        batteryPct = 94,
        batteryVoltage = 4.10f,
        deviceToken = profile.token,
        firmwareVersion = "RAMS-SAFETY-CLIENT v3.2",
        ipAddress = sync.esp32Ip,
        port = sync.esp32Port,
        wsUrl = sync.esp32WsUrl,
        bluetoothName = sync.btDeviceName,
        bluetoothMac = sync.btMacAddress
      )
    } else {
      simLink.copy(deviceToken = profile.token)
    }
  }.stateIn(viewModelScope, SharingStarted.Eagerly, DeviceLinkStatus())

  val syncStatus: StateFlow<Esp32SyncStatus> = esp32SyncEngine.syncStatus

  // Waveform buffer for IMU sparklines (last 50 data points)
  private val _imuHistory = MutableStateFlow<List<ImuData>>(emptyList())
  val imuHistory: StateFlow<List<ImuData>> = _imuHistory.asStateFlow()

  // Peak G-force recorder
  private val _peakAMag = MutableStateFlow(1.02f)
  val peakAMag: StateFlow<Float> = _peakAMag.asStateFlow()

  // Incident Events Stream
  private val _events = MutableStateFlow<List<IncidentEvent>>(createInitialEvents())
  val events: StateFlow<List<IncidentEvent>> = _events.asStateFlow()

  // Selected event for Profile Overlay Showcase
  private val _selectedEvent = MutableStateFlow<IncidentEvent?>(null)
  val selectedEvent: StateFlow<IncidentEvent?> = _selectedEvent.asStateFlow()

  // Dialog & Overlay visibility
  private val _showProfileOverlay = MutableStateFlow(false)
  val showProfileOverlay: StateFlow<Boolean> = _showProfileOverlay.asStateFlow()

  private val _showConnectionDialog = MutableStateFlow(false)
  val showConnectionDialog: StateFlow<Boolean> = _showConnectionDialog.asStateFlow()

  private val _showRiderLoginDialog = MutableStateFlow(false)
  val showRiderLoginDialog: StateFlow<Boolean> = _showRiderLoginDialog.asStateFlow()

  private val _showCsvDialog = MutableStateFlow(false)
  val showCsvDialog: StateFlow<Boolean> = _showCsvDialog.asStateFlow()

  private val _showDesignRulesDialog = MutableStateFlow(false)
  val showDesignRulesDialog: StateFlow<Boolean> = _showDesignRulesDialog.asStateFlow()

  // Theme mode (Dark / Light)
  private val _isDarkTheme = MutableStateFlow(true)
  val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

  // Filter & Search
  private val _activeFilter = MutableStateFlow("ALL")
  val activeFilter: StateFlow<String> = _activeFilter.asStateFlow()

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  // Bluetooth Wearable Scanner State
  private val bluetoothManager = application.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
  private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

  private val _isBluetoothEnabled = MutableStateFlow(bluetoothAdapter?.isEnabled == true)
  val isBluetoothEnabled: StateFlow<Boolean> = _isBluetoothEnabled.asStateFlow()

  private val _isScanningBluetooth = MutableStateFlow(false)
  val isScanningBluetooth: StateFlow<Boolean> = _isScanningBluetooth.asStateFlow()

  private val _bondedDevices = MutableStateFlow<List<BluetoothDevice>>(emptyList())
  val bondedDevices: StateFlow<List<BluetoothDevice>> = _bondedDevices.asStateFlow()

  private val _discoveredWearables = MutableStateFlow<List<BluetoothDevice>>(emptyList())
  val discoveredWearables: StateFlow<List<BluetoothDevice>> = _discoveredWearables.asStateFlow()

  private var isReceiverRegistered = false
  private var leScanCallback: android.bluetooth.le.ScanCallback? = null
  private var scanCycleCount = 0

  private fun sortWearables(devices: List<BluetoothDevice>): List<BluetoothDevice> {
    return devices.sortedWith(compareByDescending { device ->
      try {
        val name = device.name ?: ""
        name.contains("RAMS", ignoreCase = true) || name.contains("Wearable", ignoreCase = true)
      } catch (_: SecurityException) { false }
    })
  }

  fun refreshBluetoothState() {
    val enabled = bluetoothAdapter?.isEnabled == true
    _isBluetoothEnabled.value = enabled
    if (enabled) {
      queryBondedWearableDevices()
      startBluetoothDiscovery()
    }
  }

  private val bluetoothScanReceiver = object : BroadcastReceiver() {
    @SuppressLint("MissingPermission")
    override fun onReceive(context: Context?, intent: Intent?) {
      when (intent?.action) {
        BluetoothAdapter.ACTION_STATE_CHANGED -> {
          val state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
          if (state == BluetoothAdapter.STATE_ON) {
            _isBluetoothEnabled.value = true
            queryBondedWearableDevices()
            startBluetoothDiscovery()
          } else if (state == BluetoothAdapter.STATE_OFF) {
            _isBluetoothEnabled.value = false
            _isScanningBluetooth.value = false
            _discoveredWearables.value = emptyList()
            _bondedDevices.value = emptyList()
          }
        }
        BluetoothDevice.ACTION_FOUND -> {
          val device: BluetoothDevice? = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
          if (device != null) {
            val currentList = _discoveredWearables.value.toMutableList()
            if (!currentList.any { it.address == device.address }) {
              currentList.add(device)
              _discoveredWearables.value = sortWearables(currentList)
            }
          }
        }
        BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
          if (_isScanningBluetooth.value && scanCycleCount < 2) {
            scanCycleCount++
            try {
              bluetoothAdapter?.startDiscovery()
            } catch (_: Exception) {
              _isScanningBluetooth.value = false
            }
          } else {
            _isScanningBluetooth.value = false
          }
        }
      }
    }
  }

  val filteredEvents: StateFlow<List<IncidentEvent>> = combine(
    _events,
    _activeFilter,
    _searchQuery
  ) { eventList, filter, query ->
    eventList.filter { event ->
      val matchesFilter = when (filter) {
        "ALERT" -> event.type == IncidentType.ALERT
        "TEST" -> event.type == IncidentType.TEST
        "TELEMETRY" -> event.type == IncidentType.TELEMETRY
        else -> true
      }
      val matchesQuery = query.isEmpty() ||
          event.riderName.contains(query, ignoreCase = true) ||
          event.deviceToken.contains(query, ignoreCase = true) ||
          event.title.contains(query, ignoreCase = true) ||
          event.plateNumber.contains(query, ignoreCase = true)
      matchesFilter && matchesQuery
    }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), _events.value)

  init {
    // Start phone physical sensors
    phoneSensorEngine.startSensors()

    // Register Bluetooth broadcast receiver
    try {
      val filter = IntentFilter().apply {
        addAction(BluetoothDevice.ACTION_FOUND)
        addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
      }
      application.registerReceiver(bluetoothScanReceiver, filter)
      isReceiverRegistered = true
    } catch (_: Exception) {}

    // Collect IMU to update history buffer, peak G, and CSV logging
    viewModelScope.launch {
      imuState.collect { imu ->
        val currentList = _imuHistory.value.toMutableList()
        if (currentList.size >= 50) currentList.removeAt(0)
        currentList.add(imu)
        _imuHistory.value = currentList

        if (imu.aMag > _peakAMag.value) {
          _peakAMag.value = imu.aMag
        }

        // Record to CSV logger if recording is turned on
        csvExportManager.recordSample(
          gps = gpsState.value,
          imu = imu,
          battPct = 94
        )
      }
    }

    // Collect Real Phone Crash Alert Events
    viewModelScope.launch {
      phoneSensorEngine.crashTriggerFlow.collect { (gps, imu) ->
        handleCrashShockDetected(gps, imu, "PHONE SENSOR IMPACT DETECTED")
      }
    }

    // Populate paired Wearable devices on startup if bluetooth is active
    if (bluetoothAdapter?.isEnabled == true) {
      queryBondedWearableDevices()
      startBluetoothDiscovery()
    }
  }

  @SuppressLint("MissingPermission")
  fun queryBondedWearableDevices() {
    try {
      val bonded = bluetoothAdapter?.bondedDevices ?: emptySet()
      _bondedDevices.value = sortWearables(bonded.toList())
    } catch (_: Exception) {}
  }

  @SuppressLint("MissingPermission")
  fun startBluetoothDiscovery() {
    val app = getApplication<Application>()
    val enabled = bluetoothAdapter?.isEnabled == true
    _isBluetoothEnabled.value = enabled
    if (!enabled) return

    try {
      if (!isReceiverRegistered) {
        val filter = IntentFilter().apply {
          addAction(BluetoothDevice.ACTION_FOUND)
          addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
          addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        app.registerReceiver(bluetoothScanReceiver, filter)
        isReceiverRegistered = true
      }

      // Check bonded devices first
      queryBondedWearableDevices()

      // Reset discovered list and cycle counter for fresh scan
      _discoveredWearables.value = emptyList()
      scanCycleCount = 0

      if (bluetoothAdapter?.isDiscovering == true) {
        bluetoothAdapter.cancelDiscovery()
      }
      val startedDiscovery = bluetoothAdapter?.startDiscovery() ?: false

      // Also start BLE scanner for ESP32-S3 and other BLE peripherals
      val leScanner = bluetoothAdapter?.bluetoothLeScanner
      var startedBle = false
      if (leScanner != null) {
        if (leScanCallback == null) {
          leScanCallback = object : android.bluetooth.le.ScanCallback() {
            override fun onScanResult(callbackType: Int, result: android.bluetooth.le.ScanResult?) {
              result?.device?.let { device ->
                val currentList = _discoveredWearables.value.toMutableList()
                if (!currentList.any { it.address == device.address }) {
                  currentList.add(device)
                  _discoveredWearables.value = sortWearables(currentList)
                }
              }
            }

            override fun onBatchScanResults(results: MutableList<android.bluetooth.le.ScanResult>?) {
              results?.forEach { result ->
                result.device?.let { device ->
                  val currentList = _discoveredWearables.value.toMutableList()
                  if (!currentList.any { it.address == device.address }) {
                    currentList.add(device)
                    _discoveredWearables.value = sortWearables(currentList)
                  }
                }
              }
            }

            override fun onScanFailed(errorCode: Int) {}
          }
        }
        try {
          val settings = android.bluetooth.le.ScanSettings.Builder()
            .setScanMode(android.bluetooth.le.ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()
          leScanner.startScan(null, settings, leScanCallback)
          startedBle = true
        } catch (_: Exception) {}
      }

      _isScanningBluetooth.value = startedDiscovery || startedBle
    } catch (e: Exception) {
      _isScanningBluetooth.value = false
    }
  }

  @SuppressLint("MissingPermission")
  fun stopBluetoothDiscovery() {
    try {
      scanCycleCount = 99
      if (bluetoothAdapter?.isDiscovering == true) {
        bluetoothAdapter.cancelDiscovery()
      }
      leScanCallback?.let { cb ->
        try {
          bluetoothAdapter?.bluetoothLeScanner?.stopScan(cb)
        } catch (_: Exception) {}
      }
      _isScanningBluetooth.value = false
    } catch (_: Exception) {}
  }

  fun cancelFalseAlarm() {
    val currentRider = _riderProfile.value
    esp32SyncEngine.sendCancelAlertPacket(currentRider)

    val cancelEvent = IncidentEvent(
      id = "CLR-${System.currentTimeMillis() % 100000}",
      title = "FALSE ALARM DISMISSED",
      type = IncidentType.FALSE_ALARM,
      timestamp = System.currentTimeMillis(),
      lat = gpsState.value.latitude,
      lon = gpsState.value.longitude,
      aMag = imuState.value.aMag,
      speedKmh = gpsState.value.speedKmh,
      batteryPct = 94,
      riderName = currentRider.riderName,
      plateNumber = currentRider.plateNumber,
      deviceToken = currentRider.token,
      vehicleModel = currentRider.vehicleModel,
      locationAddress = gpsState.value.locationAddress.ifBlank {
        if (gpsState.value.hasFix) "GPS: %.5f, %.5f".format(gpsState.value.latitude, gpsState.value.longitude)
        else "Location Pending (GPS Searching)"
      },
      notes = "False alarm signal cancelled by rider via mobile app. Wearable emergency status cleared."
    )
    _events.value = listOf(cancelEvent) + _events.value
  }

  fun connectWearableDevice(device: BluetoothDevice) {
    stopBluetoothDiscovery()
    @SuppressLint("MissingPermission")
    val deviceName = try { device.name ?: TARGET_WEARABLE_NAME } catch (_: SecurityException) { TARGET_WEARABLE_NAME }
    connectBluetoothSync(device.address, deviceName)
  }

  private fun handleCrashShockDetected(gps: GpsData, imu: ImuData, note: String) {
    val currentRider = _riderProfile.value
    val newAlert = IncidentEvent(
      id = "ALERT-${UUID.randomUUID().toString().substring(0, 6).uppercase()}",
      title = "CRASH IMPACT SENSOR SHOCK (%.2fg)".format(imu.aMag),
      type = IncidentType.ALERT,
      timestamp = System.currentTimeMillis(),
      lat = gps.latitude,
      lon = gps.longitude,
      aMag = imu.aMag,
      speedKmh = gps.speedKmh,
      batteryPct = 94,
      riderName = currentRider.riderName,
      plateNumber = currentRider.plateNumber,
      deviceToken = currentRider.token,
      vehicleModel = currentRider.vehicleModel,
      locationAddress = gps.locationAddress.ifBlank {
        if (gps.hasFix) "GPS: %.5f, %.5f".format(gps.latitude, gps.longitude)
        else "Location Pending (GPS Searching)"
      },
      notes = "$note: Peak ${imu.aMag} G shock. Device Token: ${currentRider.token}. Dispatched to Rescue Network via Safety Wearable."
    )
    _events.value = listOf(newAlert) + _events.value

    // Transmit emergency broadcast packet to Wearable
    esp32SyncEngine.sendEmergencyCrashPacket(
      gps = gps,
      imu = imu,
      riderProfile = currentRider
    )
  }

  fun toggleSensorSource() {
    _usePhoneSensors.value = !_usePhoneSensors.value
    if (_usePhoneSensors.value) {
      phoneSensorEngine.startSensors()
    }
  }

  fun toggleNearbyIncidents(show: Boolean) {
    _riderProfile.value = _riderProfile.value.copy(showNearbyIncidents = show)
  }

  fun connectWebSocketSync(wsUrl: String) {
    _riderProfile.value = _riderProfile.value.copy(wearableWsUrl = wsUrl)
    esp32SyncEngine.startWebSocketSync(
      wsUrl = wsUrl,
      getGps = { gpsState.value },
      getImu = { imuState.value },
      getRiderProfile = { _riderProfile.value }
    )
    _showConnectionDialog.value = false
  }

  fun connectWifiSync(ip: String, port: Int) {
    esp32SyncEngine.startWifiSync(
      ip = ip,
      port = port,
      getGps = { gpsState.value },
      getImu = { imuState.value },
      getRiderProfile = { _riderProfile.value }
    )
    _showConnectionDialog.value = false
  }

  fun connectBluetoothSync(mac: String, name: String) {
    stopBluetoothDiscovery()
    esp32SyncEngine.startBluetoothSync(
      mac = mac,
      name = name,
      getGps = { gpsState.value },
      getImu = { imuState.value },
      getRiderProfile = { _riderProfile.value }
    )
    _showConnectionDialog.value = false
  }

  fun saveRiderProfile(profile: RiderProfile) {
    _riderProfile.value = profile
    // Persist to SharedPreferences so data survives app restarts
    profile.saveToPreferences(getApplication<Application>().applicationContext)
  }

  fun generateNewToken() {
    val newToken = RiderProfile.generateNewToken()
    _riderProfile.value = _riderProfile.value.copy(token = newToken)
  }

  fun startSimulation() {
    _usePhoneSensors.value = false
    simulatedConnectionManager.startSimulation()
  }

  fun resetPeakG() {
    _peakAMag.value = imuState.value.aMag
  }

  fun selectEvent(event: IncidentEvent) {
    _selectedEvent.value = event
    _showProfileOverlay.value = true
  }

  fun closeProfileOverlay() {
    _showProfileOverlay.value = false
  }

  fun setConnectionDialogVisible(visible: Boolean) {
    _showConnectionDialog.value = visible
  }

  fun setRiderLoginDialogVisible(visible: Boolean) {
    _showRiderLoginDialog.value = visible
  }

  fun setCsvDialogVisible(visible: Boolean) {
    _showCsvDialog.value = visible
  }

  fun setDesignRulesDialogVisible(visible: Boolean) {
    _showDesignRulesDialog.value = visible
  }

  fun toggleTheme() {
    _isDarkTheme.value = !_isDarkTheme.value
  }

  fun setFilter(filter: String) {
    _activeFilter.value = filter
  }

  fun setSearch(query: String) {
    _searchQuery.value = query
  }

  fun toggleRecording() {
    if (csvExportManager.isRecording.value) {
      csvExportManager.stopRecording()
    } else {
      csvExportManager.startRecording()
    }
  }

  fun exportCsv() {
    csvExportManager.shareCsv()
  }

  fun clearLogs() {
    csvExportManager.clearLogs()
  }

  override fun onCleared() {
    super.onCleared()
    phoneSensorEngine.stopSensors()
    esp32SyncEngine.stopSync()
    if (isReceiverRegistered) {
      try {
        getApplication<Application>().unregisterReceiver(bluetoothScanReceiver)
      } catch (_: Exception) {}
      isReceiverRegistered = false
    }
  }

  companion object {
    const val TARGET_WEARABLE_NAME = "RAMS Bluetooth Connection"
  }

  private fun createInitialEvents(): List<IncidentEvent> {
    val now = System.currentTimeMillis()
    return listOf(
      IncidentEvent(
        id = "EVT-8821-CRASH",
        title = "CRASH IMPACT SENSOR TRIGGER",
        type = IncidentType.ALERT,
        timestamp = now - 180000L,
        lat = 17.613210,
        lon = 121.727040,
        aMag = 3.82f,
        speedKmh = 52.4f,
        batteryPct = 94,
        riderName = "Nearby Road Unit",
        plateNumber = "NCR-8821",
        vehicleModel = "Road Vehicle",
        deviceToken = "RAMS-41A0",
        locationAddress = "Maharlika Highway cor. Caritan Norte, Tuguegarao City",
        notes = "Sudden high-G lateral impact detected on IMU with tilt angle > 70 deg. Token: RAMS-41A0. Dispatched to Rescue Network."
      ),
      IncidentEvent(
        id = "EVT-8821-TEST",
        title = "PRE-TRIP SENSOR CALIBRATION",
        type = IncidentType.TEST,
        timestamp = now - 950000L,
        lat = 17.615200,
        lon = 121.729500,
        aMag = 1.01f,
        speedKmh = 12.0f,
        batteryPct = 96,
        riderName = "Unit Diagnostic",
        deviceToken = "RAMS-41A0",
        notes = "Hardware sensor diagnostic passed: Accelerometer and Gyro OK"
      ),
      IncidentEvent(
        id = "EVT-8821-FALSE",
        title = "POTHOLE SHOCK RESOLVED",
        type = IncidentType.FALSE_ALARM,
        timestamp = now - 1800000L,
        lat = 17.617500,
        lon = 121.729200,
        aMag = 2.15f,
        speedKmh = 38.0f,
        batteryPct = 98,
        riderName = "Nearby Road Unit",
        deviceToken = "RAMS-41A0",
        notes = "Vertical bump without vehicle capsize; cleared by operator confirmation"
      ),
      IncidentEvent(
        id = "EVT-8821-TELEM",
        title = "LIVE TELEMETRY SNAPSHOT",
        type = IncidentType.TELEMETRY,
        timestamp = now - 60000L,
        lat = 17.614100,
        lon = 121.728200,
        aMag = 1.00f,
        speedKmh = 44.5f,
        batteryPct = 94,
        riderName = "Safety Wearable Stream",
        deviceToken = "RAMS-41A0",
        notes = "Normal IMU and GPS sync to Autonomous Safety Gateway"
      )
    )
  }
}
