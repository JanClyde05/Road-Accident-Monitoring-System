# Application exhibit records

## Rider's phone

The Wearable and Telemetry images are portrait renders of the current Android Jetpack Compose screen functions. The Roborazzi runner uses Android API 35, the app's dark theme, an empty rider profile, disconnected link state and an empty IMU sample history. The telemetry values visible on the screen come from the Kotlin `ImuData()` default constructor. These isolated screen renders omit the navigation shell and handset status bar. They represent the UI in a fixture session. The [capture inputs](../../src/app-exhibits/capture-tests/ExhibitScreens.kt) are included in the development checkout.

The Voice image is a crop of the archived handset screenshot at `archive/duplicates/mobile_ai_app_2026-11/rams_live_screen.png`. It retains the wake overlay. The crop excludes the device token, handset status bar and an example emergency message. Use this image to identify the interaction in that earlier build. The current recognizer delegates speech transcription to Android and processes the transcript in `VoiceAlarmCanceler.kt`.

## Rescuer's Windows station

The browser loaded the HTML, JavaScript and CSS shipped in `apps/new_ai_applications/desktop_ai_app/www` for these captures. An isolated fixture provided an empty rider registry, empty event and ping lists, an unset station location and an empty hotspot result. All remote requests were blocked. The Windows receiver, serial port and location services were outside this recording.

- **Reception** shows the source `ping.html` interface. Its example airtime estimate belongs to the screen's radio model. A field latency claim would require timestamps.
- **Unit registry** crops the registered-rider panel from the shipping dashboard. The blank state explains how incoming units will appear.
- **Hotspots** crops the dashboard's AI Operations Suite. The implementation in `HotspotPredictor.cs` groups stored incident coordinates using Haversine distances and DBSCAN. The default parameters are a 150 m neighborhood and a minimum of three points.

## RAMS AI evidence

The APK's `rams_distilled_knowledge.jsonl` has 1,655 rows and 1,655 distinct normalized keys. Every packaged row has the source label `RAMS-AutoTrain-Corpus-v3.2`. The build script expands domain question and answer templates. The on-device assistant also has a separate mechanism for caching answers returned by Gemini at runtime. It stores the query, its normalized key, the response and context locally. An exact key can be recalled offline.

In `voice_wake_patterns.json`, the base collections contain 32 wake prefixes, 55 written name variants, 30 slurred forms and 78 cancel phrases. The loader in `VoiceAlarmCanceler.kt` combines prefixes and name variants both with and without a space, adds slurred or regional forms, and checks recognized text. The historical methodology's recording profiles and the JSON metadata describe additional ambitions. These text resources establish the implemented phrase inventory. Independent speaker trials would be needed to measure wake or cancellation accuracy.

The archive gives the project identity `RAMS-1.8B-Edge` and a proposed architecture. The implemented paths traced here are Android speech transcription, deterministic action routing, device-context replies, local Q&A retrieval and optional online Gemini calls. No verified 1.8B checkpoint or local neural-weight training run was identified among the Android assets.

