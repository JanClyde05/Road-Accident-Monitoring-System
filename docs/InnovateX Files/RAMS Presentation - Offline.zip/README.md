# RAMS - Road Accident Monitoring System

Extract the offline ZIP, then open **index.html** in Chrome or Edge. The complete exhibit runs from disk, including the fonts, scene geometry, app captures and motion traces. WebGL 2 adds interactive terrain, incident replays and both board models. Browsers without WebGL show local stills of the same subjects.

## Presenting

Use the program selector to choose the **15-chapter walkthrough** (17 minutes 30 seconds) or the **11-chapter finals talk** (6 minutes). Advance with the arrow keys, a clicker or the on-screen controls. **F** toggles fullscreen, **N** opens the current chapter’s field notes, **I** opens the index and **Esc** closes a dialog. Chapter timings are rehearsal cues. The finals schedule reserves another four minutes for the physical prototype and five for questions.

The five names follow the research manuscript cover. The speaking assignments are proposed for rehearsal.

| Presenter | What to show in the full exhibit |
| --- | --- |
| Ernest John Galace | Open on the road corridor. Introduce the research team, the Philippine context and the question of who reports an unwitnessed crash. |
| Precious Nina Garcia | Follow the rider through pairing. Compare a motorcycle slide, a two-car collision and a pedestrian strike. Pause or scrub each reconstruction, then inspect the Android app. |
| April Ann Palattao | Compare acceleration during ordinary and accident-like movement. Inspect eleven generated motion families, the public dataset catalog and the labeled-session calibration example. |
| Stephanie Ranjo | Try a RAMS AI example, inspect the fabricated SuperMini carrier and custom four-layer J2 design, then follow an alert through Bluetooth and LoRa. |
| Jan Clyde Talosig | Show the Windows receiving station. Inspect the classifier replay and subtype errors, then close with what a field trial needs to measure for riders, operators and responders. |

## Evidence

The detection chapter plots four fixtures from the Android motion benchmarks. The motion atlas plots the base trace for each of the eleven families and identifies the generated variations. The calibration example evaluates the CSV import rule on two selected fixture peaks. Its output applies to that pair. Public fall and activity datasets appear in the project’s reference catalog. The packaged benchmark inputs are generated profiles. IMU Studio provides a separate path for collecting labeled handset sessions.

RAMS AI’s examples trace device-state questions, voice normalization and local retrieval to their application sources. The mobile and Windows galleries use project interface captures with their provenance in the [app exhibit record](public/apps/sources.md). All interactions in the exhibit run locally. The illustrated incidents explain the reporting workflow and do not provide accident-detection measurements.

The [replay record](verification/replay-output.tsv) covers 121 precomputed feature vectors evaluated by the compiled Android classifier on a desktop JVM. Its header records the source, compiled class and fixture-list hashes. The [verification script](verification/replay.py) rebuilds and reruns the classifier from the project checkout. The benchmark does not measure raw sensor acquisition, BLE or LoRa performance, handset placement or field accuracy.

The [hardware record](public/hardware/sources.md) traces each exhibit to its carrier layout, component references and fabrication status. The SuperMini model reconstructs two unavailable module bodies using the manuscript’s component images. The custom SMD model depicts the normal-population J2 design. The manuscript and original CAD remain in the project checkout.

## Development

The presentation uses Three.js 0.187.0 and a local esbuild bundle. From this directory inside the RAMS repository, run `npm ci` once, then `npm run build` after a source change. Run `python pack.py` after building to replace the offline ZIP in the parent directory. `npm start` serves the site on loopback at port 8765. The prebuilt HTML also opens directly from disk.

## Visual references and credits

The road scene uses mesh-surface scan points, an animated scan band and a camera-space raindrop refraction pass. The two effect guides describe the techniques. [Point-cloud scan](https://github.com/MengTo/Skills/blob/main/agent-skills/game-development/build-point-cloud-scan/SKILL.md) · [Lens raindrops](https://github.com/MengTo/Skills/blob/main/agent-skills/game-development/build-lens-raindrops/SKILL.md)

The atmosphere and camera direction reference the requested Three.js experiences. The RAMS scene geometry, radio visualization and presentation interface were created for this exhibit. [Threejs-Punk Drive](https://www.threejspunk.com/) · [Three.js Conference](https://github.com/ektogamat/threejs-conference)

The road reconstructions use two [Kenney vehicle models](public/scenarios/kenney-license.txt). The Philippine coastline is derived from [Natural Earth](https://www.naturalearthdata.com/downloads/50m-cultural-vectors/50m-admin-0-countries-2/). The 2011 and 2021 national road-death totals are attributed to PSA in the [2023 WHO and DOTr release](https://www.who.int/philippines/news/detail/31-05-2023-department-of-transportation--world-health-organization-launch-philippine-road-safety-action-plan-2023-2028).

The presentation includes the RAMS project logo, local Plus Jakarta Sans and IBM Plex Mono fonts, and the Three.js runtime. Their open-source licenses accompany the assets. [Three.js license](assets/three-license.txt) · [Plus Jakarta Sans license](public/fonts/jakarta-license.txt) · [IBM Plex Mono license](public/fonts/plex-license.txt)
