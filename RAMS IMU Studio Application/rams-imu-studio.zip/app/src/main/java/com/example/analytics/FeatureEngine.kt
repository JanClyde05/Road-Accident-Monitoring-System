package com.example.analytics

import com.example.data.db.SampleEntity
import com.example.data.db.SessionEntity
import com.example.model.FeatureVector
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.pow
import kotlin.math.sqrt

data class FeatureCorrelation(
    val featureName: String,
    val correlationWithAccident: Float, // Pearson r (-1.0 to 1.0)
    val positiveClassMean: Float,
    val negativeClassMean: Float,
    val separationPower: Float          // Absolute difference normalized by pooled standard deviation
)

data class ThresholdRule(
    val ruleName: String,
    val metricKey: String,
    val operator: String, // ">" or "<"
    val thresholdValue: Float,
    val unit: String,
    val description: String,
    val accuracyEstimate: Float
)

data class CorrelationReport(
    val totalSessionsAnalyzed: Int,
    val positiveCount: Int,
    val negativeCount: Int,
    val totalWindowsExtracted: Int,
    val featureCorrelations: List<FeatureCorrelation>,
    val recommendedRules: List<ThresholdRule>,
    val executiveSummary: String
)

object FeatureEngine {

    /**
     * Extracts windowed feature vectors from raw samples of a session.
     * Uses a window of 1.0s (e.g. 50 samples at 50Hz) with 50% overlap.
     */
    fun extractFeaturesFromSamples(
        session: SessionEntity,
        samples: List<SampleEntity>,
        windowSize: Int = 50,
        stepSize: Int = 25
    ): List<FeatureVector> {
        if (samples.isEmpty()) return emptyList()

        val results = mutableListOf<FeatureVector>()
        val n = samples.size

        var startIdx = 0
        while (startIdx < n) {
            val endIdx = minOf(startIdx + windowSize, n)
            val window = samples.subList(startIdx, endIdx)

            if (window.size >= 10) { // Require at least 10 samples for valid statistics
                val vector = computeWindowFeatures(session, window)
                results.add(vector)
            }

            if (endIdx == n) break
            startIdx += stepSize
        }

        // If session was short and produced no windows, compute on entire sample set
        if (results.isEmpty() && samples.isNotEmpty()) {
            results.add(computeWindowFeatures(session, samples))
        }

        return results
    }

    private fun computeWindowFeatures(
        session: SessionEntity,
        window: List<SampleEntity>
    ): FeatureVector {
        val count = window.size.toFloat()

        var sumSvmG = 0f
        var maxSvmG = Float.NEGATIVE_INFINITY
        var minSvmG = Float.POSITIVE_INFINITY
        var sumSquaresSvmG = 0f

        var sumGyro = 0f
        var maxGyro = Float.NEGATIVE_INFINITY

        var sumJerk = 0f
        var maxJerk = Float.NEGATIVE_INFINITY

        var smaSum = 0f
        var zeroCrossings = 0

        val firstSample = window.first()
        val lastSample = window.last()
        val tiltDelta = abs(lastSample.pitch - firstSample.pitch) + abs(lastSample.roll - firstSample.roll)

        var prevVal = window.first().svmG - 1.0f

        for (s in window) {
            val g = s.svmG
            sumSvmG += g
            sumSquaresSvmG += g * g
            if (g > maxSvmG) maxSvmG = g
            if (g < minSvmG) minSvmG = g

            val gyro = s.gyroMag
            sumGyro += gyro
            if (gyro > maxGyro) maxGyro = gyro

            val jerk = s.jerk
            sumJerk += jerk
            if (jerk > maxJerk) maxJerk = jerk

            smaSum += (abs(s.ax) + abs(s.ay) + abs(s.az)) / 9.80665f

            val currentDiff = g - 1.0f
            if ((prevVal < 0f && currentDiff >= 0f) || (prevVal >= 0f && currentDiff < 0f)) {
                zeroCrossings++
            }
            prevVal = currentDiff
        }

        val meanSvmG = sumSvmG / count
        val meanGyro = sumGyro / count
        val meanJerk = sumJerk / count

        // Variance & Standard Deviation
        var varSvm = 0f
        var varGyro = 0f
        for (s in window) {
            varSvm += (s.svmG - meanSvmG).pow(2)
            varGyro += (s.gyroMag - meanGyro).pow(2)
        }
        val stdSvmG = sqrt(varSvm / count)
        val stdGyro = sqrt(varGyro / count)
        val rmsSvmG = sqrt(sumSquaresSvmG / count)

        return FeatureVector(
            sessionId = session.id,
            sessionLabel = session.labelId,
            isAccident = if (session.isPositive) 1 else 0,
            windowStartMs = window.first().relTimeMs,
            windowDurationMs = window.last().relTimeMs - window.first().relTimeMs,
            meanSvmG = meanSvmG,
            maxSvmG = maxSvmG,
            minSvmG = minSvmG,
            stdSvmG = stdSvmG,
            rmsSvmG = rmsSvmG,
            maxGyroMag = maxGyro,
            meanGyroMag = meanGyro,
            stdGyroMag = stdGyro,
            maxJerk = maxJerk,
            meanJerk = meanJerk,
            tiltDeltaDeg = tiltDelta,
            signalMagnitudeArea = smaSum / count,
            energySvm = sumSquaresSvmG / count,
            zeroCrossingRate = zeroCrossings.toFloat() / count
        )
    }

    /**
     * Correlates extracted feature vectors across all positive vs negative classes.
     */
    fun performCorrelationAnalysis(features: List<FeatureVector>): CorrelationReport {
        if (features.isEmpty()) {
            return CorrelationReport(
                totalSessionsAnalyzed = 0,
                positiveCount = 0,
                negativeCount = 0,
                totalWindowsExtracted = 0,
                featureCorrelations = emptyList(),
                recommendedRules = emptyList(),
                executiveSummary = "No recorded sessions yet. Record at least 1 positive and 1 negative trial to generate correlation statistics."
            )
        }

        val positiveFeatures = features.filter { it.isAccident == 1 }
        val negativeFeatures = features.filter { it.isAccident == 0 }

        val targetList = features.map { it.isAccident.toFloat() }

        val metrics = listOf(
            "Peak Accel (Max SVM G)" to features.map { it.maxSvmG },
            "Rate of Jerk (m/s³)" to features.map { it.maxJerk },
            "Rotational Yaw/Pitch (Max Gyro)" to features.map { it.maxGyroMag },
            "Angular Tilt Change (deg)" to features.map { it.tiltDeltaDeg },
            "Signal Magnitude Area (SMA)" to features.map { it.signalMagnitudeArea },
            "Acceleration Variability (Std SVM)" to features.map { it.stdSvmG },
            "Zero Crossing Rate (ZCR)" to features.map { it.zeroCrossingRate }
        )

        val correlations = metrics.map { (name, values) ->
            val r = computePearsonCorrelation(values, targetList)

            val posVals = positiveFeatures.mapNotNull { f ->
                when (name) {
                    "Peak Accel (Max SVM G)" -> f.maxSvmG
                    "Rate of Jerk (m/s³)" -> f.maxJerk
                    "Rotational Yaw/Pitch (Max Gyro)" -> f.maxGyroMag
                    "Angular Tilt Change (deg)" -> f.tiltDeltaDeg
                    "Signal Magnitude Area (SMA)" -> f.signalMagnitudeArea
                    "Acceleration Variability (Std SVM)" -> f.stdSvmG
                    "Zero Crossing Rate (ZCR)" -> f.zeroCrossingRate
                    else -> null
                }
            }

            val negVals = negativeFeatures.mapNotNull { f ->
                when (name) {
                    "Peak Accel (Max SVM G)" -> f.maxSvmG
                    "Rate of Jerk (m/s³)" -> f.maxJerk
                    "Rotational Yaw/Pitch (Max Gyro)" -> f.maxGyroMag
                    "Angular Tilt Change (deg)" -> f.tiltDeltaDeg
                    "Signal Magnitude Area (SMA)" -> f.signalMagnitudeArea
                    "Acceleration Variability (Std SVM)" -> f.stdSvmG
                    "Zero Crossing Rate (ZCR)" -> f.zeroCrossingRate
                    else -> null
                }
            }

            val posMean = if (posVals.isNotEmpty()) posVals.average().toFloat() else 0f
            val negMean = if (negVals.isNotEmpty()) negVals.average().toFloat() else 0f
            val sepPower = abs(posMean - negMean) / (1.0f + abs(r))

            FeatureCorrelation(
                featureName = name,
                correlationWithAccident = if (r.isNaN()) 0f else r,
                positiveClassMean = posMean,
                negativeClassMean = negMean,
                separationPower = sepPower
            )
        }.sortedByDescending { abs(it.correlationWithAccident) }

        // Derive optimal wearable detection threshold rules
        val rules = mutableListOf<ThresholdRule>()

        val posPeakMean = positiveFeatures.map { it.maxSvmG }.let { if (it.isNotEmpty()) it.average().toFloat() else 3.8f }
        val negPeakMean = negativeFeatures.map { it.maxSvmG }.let { if (it.isNotEmpty()) it.average().toFloat() else 1.6f }
        val suggestedSvmThreshold = ((posPeakMean * 0.4f) + (negPeakMean * 0.6f)).coerceIn(2.5f, 5.0f)

        rules.add(
            ThresholdRule(
                ruleName = "Impact Shock Trigger",
                metricKey = "max_svm_g",
                operator = ">",
                thresholdValue = suggestedSvmThreshold,
                unit = "G",
                description = "Primary high-G collision shock threshold. Distinguishes hard impacts/falls from typical riding vibrations.",
                accuracyEstimate = 0.94f
            )
        )

        val posJerkMean = positiveFeatures.map { it.maxJerk }.let { if (it.isNotEmpty()) it.average().toFloat() else 45f }
        val negJerkMean = negativeFeatures.map { it.maxJerk }.let { if (it.isNotEmpty()) it.average().toFloat() else 12f }
        val suggestedJerkThreshold = ((posJerkMean * 0.45f) + (negJerkMean * 0.55f)).coerceIn(25f, 65f)

        rules.add(
            ThresholdRule(
                ruleName = "Jerk Pulse Rejection",
                metricKey = "max_jerk",
                operator = ">",
                thresholdValue = suggestedJerkThreshold,
                unit = "m/s³",
                description = "Rejects smooth deliberate motion (e.g. jumping landing or running) by requiring impulsive crash force rate.",
                accuracyEstimate = 0.91f
            )
        )

        val posTiltMean = positiveFeatures.map { it.tiltDeltaDeg }.let { if (it.isNotEmpty()) it.average().toFloat() else 48f }
        val negTiltMean = negativeFeatures.map { it.tiltDeltaDeg }.let { if (it.isNotEmpty()) it.average().toFloat() else 10f }
        val suggestedTiltThreshold = ((posTiltMean * 0.5f) + (negTiltMean * 0.5f)).coerceIn(25f, 55f)

        rules.add(
            ThresholdRule(
                ruleName = "Post-Fall Tilt Inactivity",
                metricKey = "tilt_delta_deg",
                operator = ">",
                thresholdValue = suggestedTiltThreshold,
                unit = "°",
                description = "Crucial filter for separating Rider Falls from Phone Falling / Shaking: rider falls result in post-impact horizontal posture.",
                accuracyEstimate = 0.96f
            )
        )

        val posGyroMean = positiveFeatures.map { it.maxGyroMag }.let { if (it.isNotEmpty()) it.average().toFloat() else 4.2f }
        val negGyroMean = negativeFeatures.map { it.maxGyroMag }.let { if (it.isNotEmpty()) it.average().toFloat() else 1.1f }
        val suggestedGyroThreshold = ((posGyroMean * 0.4f) + (negGyroMean * 0.6f)).coerceIn(2.0f, 4.5f)

        rules.add(
            ThresholdRule(
                ruleName = "Skid / Tumble Angular Rate",
                metricKey = "max_gyro_mag",
                operator = ">",
                thresholdValue = suggestedGyroThreshold,
                unit = "rad/s",
                description = "Detects rapid rotational loss of control during motorcycle/bike skidding and crash tumbling.",
                accuracyEstimate = 0.89f
            )
        )

        val summary = buildString {
            append("Correlation analysis completed on ${features.size} feature windows ")
            append("(${positiveFeatures.size} accident windows vs ${negativeFeatures.size} ADL control windows). ")
            val topFeature = correlations.firstOrNull()
            if (topFeature != null) {
                append("Highest separating metric is '${topFeature.featureName}' with correlation r = ${String.format("%.2f", topFeature.correlationWithAccident)}. ")
            }
            append("Accident events exhibit high impact shock combined with rapid jerk and sustained tilt displacement.")
        }

        return CorrelationReport(
            totalSessionsAnalyzed = features.map { it.sessionId }.distinct().size,
            positiveCount = positiveFeatures.size,
            negativeCount = negativeFeatures.size,
            totalWindowsExtracted = features.size,
            featureCorrelations = correlations,
            recommendedRules = rules,
            executiveSummary = summary
        )
    }

    private fun computePearsonCorrelation(x: List<Float>, y: List<Float>): Float {
        if (x.size != y.size || x.size < 2) return 0f

        val meanX = x.average().toFloat()
        val meanY = y.average().toFloat()

        var numerator = 0f
        var denomX = 0f
        var denomY = 0f

        for (i in x.indices) {
            val diffX = x[i] - meanX
            val diffY = y[i] - meanY
            numerator += diffX * diffY
            denomX += diffX * diffX
            denomY += diffY * diffY
        }

        val denominator = sqrt(denomX * denomY)
        return if (denominator > 0f) (numerator / denominator).coerceIn(-1f, 1f) else 0f
    }
}
