/* RAMS Wearable Client Helper - WebSockets */
var ws = null;
var wsReady = false;
var reconnectTimer = null;

function getWsUrl() {
  var host = window.location.hostname || '192.168.4.1';
  return 'ws://' + host + ':81/';
}

function initWebSocket(onMessageCallback) {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }

  updateConnectionStatus('connecting');

  try {
    ws = new WebSocket(getWsUrl());

    ws.onopen = function() {
      wsReady = true;
      updateConnectionStatus('connected');
      console.log('[WS] Connected to wearable port 81');
      if (reconnectTimer) {
        clearTimeout(reconnectTimer);
        reconnectTimer = null;
      }
    };

    ws.onclose = function() {
      wsReady = false;
      updateConnectionStatus('disconnected');
      console.log('[WS] Disconnected, scheduling reconnect...');
      scheduleReconnect(onMessageCallback);
    };

    ws.onerror = function(err) {
      console.warn('[WS] Error:', err);
      wsReady = false;
      updateConnectionStatus('disconnected');
    };

    ws.onmessage = function(evt) {
      try {
        var data = JSON.parse(evt.data);
        if (typeof onMessageCallback === 'function') {
          onMessageCallback(data);
        }
      } catch (ex) {
        console.error('[WS] Parse error:', ex);
      }
    };
  } catch (e) {
    console.error('[WS] Init exception:', e);
    scheduleReconnect(onMessageCallback);
  }
}

function scheduleReconnect(cb) {
  if (reconnectTimer) return;
  reconnectTimer = setTimeout(function() {
    reconnectTimer = null;
    initWebSocket(cb);
  }, 2000);
}

function updateConnectionStatus(state) {
  var dot = document.getElementById('wsDot');
  var txt = document.getElementById('wsText');
  if (!dot || !txt) return;

  dot.className = 'badge-dot ' + state;
  if (state === 'connected') {
    txt.textContent = 'WEBSOCKET ACTIVE';
  } else if (state === 'connecting') {
    txt.textContent = 'CONNECTING...';
  } else {
    txt.textContent = 'DISCONNECTED';
  }
}

function sendWsMessage(obj) {
  if (!ws || ws.readyState !== WebSocket.OPEN) {
    return false;
  }
  ws.send(JSON.stringify(obj));
  return true;
}
