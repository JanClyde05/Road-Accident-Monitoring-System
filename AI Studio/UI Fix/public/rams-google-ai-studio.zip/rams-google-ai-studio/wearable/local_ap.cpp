/*
 * Road Accident Monitoring System — Local SoftAP Implementation
 * ================================================================
 * Setup-mode WiFi AP + Captive Portal + WebSocket + HTTP server.
 * 
 * Features:
 *   - Auto-opening Captive Portal (DNSServer redirect to 192.168.4.1)
 *   - Serves static files directly from LittleFS (/data folder)
 *   - Embedded PROGMEM fallback if LittleFS is unformatted/unflashed
 *   - WebSocket Server (port 81) for real-time bidirectional communication:
 *       Registration: {"type":"register","name":"...","driveLink":"..."}
 *       Telemetry:    {"type":"tel","ax":...,"ay":...,"az":...,"gx":...,"gy":...,"gz":...,"am":...,"fsm":...}
 *       GPS:          {"type":"gps","lat":...,"lon":...,"sats":...,"fix":...}
 *   - WiFi radio is completely shut down when exiting setup mode (zero battery drain).
 */

#include "local_ap.h"
#include "config.h"
#include "registration.h"
#include "offline_map.h"
#include "lora_tx.h"
#include "../shared/logo_data.h"

#include <WiFi.h>
#include <WebServer.h>
#include <WebSocketsServer.h>
#include <DNSServer.h>
#include <LittleFS.h>
#include <ArduinoJson.h>

static WebServer _httpServer(80);
static WebSocketsServer _wsServer(SETUP_WS_PORT);
static DNSServer _dnsServer;
static bool _active = false;
static bool _littleFsOk = false;

// ── Content-Type Resolution ─────────────────────────────────────────────────
static String _getContentType(const String& path) {
  if (path.endsWith(".html") || path.endsWith(".htm")) return "text/html";
  if (path.endsWith(".css"))  return "text/css";
  if (path.endsWith(".js"))   return "application/javascript";
  if (path.endsWith(".json")) return "application/json";
  if (path.endsWith(".jpg") || path.endsWith(".jpeg")) return "image/jpeg";
  if (path.endsWith(".png"))  return "image/png";
  if (path.endsWith(".ico"))  return "image/x-icon";
  return "text/plain";
}

// ── LittleFS File Streaming Helper ──────────────────────────────────────────
static bool _serveFromLittleFS(const String& path) {
  if (!_littleFsOk) return false;
  String filePath = path;
  if (filePath.endsWith("/")) filePath += "index.html";

  if (!LittleFS.exists(filePath)) {
    return false;
  }

  File f = LittleFS.open(filePath, "r");
  if (!f) return false;

  String contentType = _getContentType(filePath);
  _httpServer.streamFile(f, contentType);
  f.close();
  return true;
}

// ── Inline Fallback HTML (Served if LittleFS Data Folder Not Flashed) ────────
static const char FALLBACK_REGISTRATION_HTML[] PROGMEM = R"rawliteral(<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>RAMS — Device Registration</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Plus Jakarta Sans',sans-serif;background:#060913;color:#f4f4f5;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.card{background:#0e1230;border:1px solid #27272a;border-radius:16px;padding:28px;max-width:440px;width:100%;box-shadow:0 20px 40px rgba(0,0,0,0.6)}
h1{font-size:15px;font-weight:900;text-transform:uppercase;color:#fff;text-align:center}
.sub{text-align:center;font-size:10px;font-family:monospace;color:#a1a1aa;margin:6px 0 20px}
label{display:block;font-family:monospace;font-size:10px;color:#a1a1aa;margin:12px 0 4px;text-transform:uppercase}
input{width:100%;padding:11px 14px;background:#18181b;border:1px solid #27272a;border-radius:10px;color:#fff;font-family:monospace;outline:none}
button{width:100%;padding:12px;margin-top:20px;background:#fff;color:#09090b;font-weight:800;border:none;border-radius:10px;cursor:pointer;font-family:monospace;text-transform:uppercase}
#status{margin-top:14px;padding:10px;border-radius:8px;font-family:monospace;font-size:11px;text-align:center;display:none}
.nav{text-align:center;margin-top:20px;font-family:monospace;font-size:11px}
.nav a{color:#fff;text-decoration:none;padding:6px 12px;background:#18181b;border:1px solid #27272a;border-radius:8px;margin:0 4px}
</style></head><body>
<div class="card">
<h1>Road Accident Monitoring</h1>
<p class="sub">Setup Mode (Fallback Firmware View)</p>
<label>Rider Name</label>
<input type="text" id="name" placeholder="e.g. Juan Dela Cruz">
<label>Drive Photo Link</label>
<input type="url" id="link" placeholder="https://drive.google.com/...">
<button id="btn" onclick="doReg()">Register Device</button>
<div id="status"></div>
<div class="nav"><a href="/telemetry">Telemetry</a><a href="/map">Map</a></div>
</div>
<script>
var ws=new WebSocket('ws://'+location.hostname+':81/');
ws.onmessage=function(e){
  try{
    var d=JSON.parse(e.data);
    if(d.type==='register_result'){
      var s=document.getElementById('status');
      s.style.display='block';
      s.style.color=d.success?'#34d399':'#f87171';
      s.textContent=d.success?'REGISTERED: '+d.token:'ERROR: '+(d.error||'Failed');
    }
  }catch(x){}
};
function doReg(){
  var n=document.getElementById('name').value.trim();
  var l=document.getElementById('link').value.trim();
  if(!n||!l)return;
  document.getElementById('status').style.display='block';
  document.getElementById('status').textContent='Registering...';
  ws.send(JSON.stringify({type:'register',name:n,driveLink:l}));
}
</script></body></html>)rawliteral";

// ── WebSocket Event Handler (Safe Buffer Parsing) ───────────────────────────
static void _onWebSocketEvent(uint8_t clientNum, WStype_t type, uint8_t* payload, size_t length) {
  switch (type) {
    case WStype_CONNECTED:
      Serial.printf("[AP] WebSocket client #%u connected\n", clientNum);
      break;

    case WStype_DISCONNECTED:
      Serial.printf("[AP] WebSocket client #%u disconnected\n", clientNum);
      break;

    case WStype_TEXT: {
      // Safe parsing using length prevents heap buffer over-read (Finding 3)
      JsonDocument doc;
      DeserializationError err = deserializeJson(doc, payload, length);
      if (err) {
        Serial.printf("[AP] Invalid WS JSON payload: %s\n", err.c_str());
        break;
      }

      const char* msgType = doc["type"] | "";

      if (strcmp(msgType, "register") == 0) {
        const char* name = doc["name"] | "";
        const char* driveLink = doc["driveLink"] | "";

        Serial.printf("[AP] Processing registration for '%s'...\n", name);
        bool success = registrationProcess(String(name), String(driveLink));

        String response;
        if (success) {
          String token = registrationGetToken();
          response = "{\"type\":\"register_result\",\"success\":true,\"token\":\"" + token + "\"}";
          
          // Transmit registration packet over LoRa to receiver / cloud backend
          String photoUrl = registrationGetPhotoUrl();
          loraSendRegister(token.c_str(), name, photoUrl.c_str());
          Serial.printf("[AP] Registration successful. Token: %s\n", token.c_str());
        } else {
          response = "{\"type\":\"register_result\",\"success\":false,\"error\":\"Invalid Drive link or flash error\"}";
          Serial.println(F("[AP] Registration rejected."));
        }

        _wsServer.sendTXT(clientNum, response);
      }
      break;
    }

    default:
      break;
  }
}

// ── Captive Portal & WebServer Routing Setup ────────────────────────────────
static void _setupHttpRoutes() {
  // 1. Root / Registration Page
  _httpServer.on("/", HTTP_GET, []() {
    if (!_serveFromLittleFS("/index.html")) {
      _httpServer.send_P(200, "text/html", FALLBACK_REGISTRATION_HTML);
    }
  });

  // 2. Telemetry Dashboard
  _httpServer.on("/telemetry", HTTP_GET, []() {
    if (!_serveFromLittleFS("/telemetry.html")) {
      _httpServer.send(200, "text/html", F("<h2>Live Telemetry</h2><p>Please upload LittleFS data folder.</p>"));
    }
  });

  // 3. Offline Map Page
  _httpServer.on("/map", HTTP_GET, []() {
    if (!_serveFromLittleFS("/map.html")) {
      _httpServer.send(200, "text/html", offlineMapGetHTML());
    }
  });

  // 4. Captive Portal OS Detection Endpoints (Direct Redirect to Root)
  // Android connectivity check probes:
  _httpServer.on("/generate_204", HTTP_GET, []() {
    _httpServer.sendHeader("Location", "http://" + WiFi.softAPIP().toString() + "/", true);
    _httpServer.send(302, "text/plain", "");
  });
  _httpServer.on("/gen_204", HTTP_GET, []() {
    _httpServer.sendHeader("Location", "http://" + WiFi.softAPIP().toString() + "/", true);
    _httpServer.send(302, "text/plain", "");
  });

  // Apple / iOS / macOS Captive Network Assistant probe:
  _httpServer.on("/hotspot-detect.html", HTTP_GET, []() {
    _httpServer.sendHeader("Location", "http://" + WiFi.softAPIP().toString() + "/", true);
    _httpServer.send(302, "text/plain", "");
  });

  // Windows connectivity probes:
  _httpServer.on("/ncsi.txt", HTTP_GET, []() {
    _httpServer.send(200, "text/plain", "Microsoft NCSI");
  });
  _httpServer.on("/connecttest.txt", HTTP_GET, []() {
    _httpServer.sendHeader("Location", "http://" + WiFi.softAPIP().toString() + "/", true);
    _httpServer.send(302, "text/plain", "");
  });

  // 5. Catch-All Not Found / Static File Handler / Captive Redirect
  _httpServer.onNotFound([]() {
    String uri = _httpServer.uri();
    
    // Attempt to serve file directly from LittleFS (e.g., /style.css, /app.js, /logo.jpg)
    if (_serveFromLittleFS(uri)) {
      return;
    }

    // Redirect any unknown external web traffic to captive portal root
    Serial.printf("[AP] Captive redirect for URI: %s\n", uri.c_str());
    _httpServer.sendHeader("Location", "http://" + WiFi.softAPIP().toString() + "/", true);
    _httpServer.send(302, "text/plain", "");
  });
}

// ── Public API ──────────────────────────────────────────────────────────────
void localApStart() {
  if (_active) return;

  // Mount LittleFS to serve /data web assets
  _littleFsOk = LittleFS.begin(true);
  if (!_littleFsOk) {
    Serial.println(F("[AP] LittleFS mount failed — will use inline HTML fallback"));
  } else {
    Serial.println(F("[AP] LittleFS mounted successfully"));
  }

  // Start SoftAP
  WiFi.mode(WIFI_AP);
  WiFi.softAP(SETUP_AP_SSID, nullptr, SETUP_AP_CHANNEL);
  delay(100);

  IPAddress apIP = WiFi.softAPIP();
  Serial.print(F("[AP] SoftAP started: "));
  Serial.print(SETUP_AP_SSID);
  Serial.print(F(" | IP: "));
  Serial.println(apIP);

  // Start DNS Server for automatic captive portal capture (port 53)
  _dnsServer.start(53, "*", apIP);
  Serial.println(F("[AP] Captive Portal DNS server started on port 53"));

  // Setup Web Server routes & start
  _setupHttpRoutes();
  _httpServer.begin();

  // Start WebSocket Server on port 81
  _wsServer.begin();
  _wsServer.onEvent(_onWebSocketEvent);

  _active = true;
  Serial.printf("[AP] HTTP (port 80) + WebSocket (port %d) active\n", SETUP_WS_PORT);
}

void localApStop() {
  if (!_active) return;

  _dnsServer.stop();
  _wsServer.disconnect();
  _httpServer.close();

  // Fully shut down WiFi radio — critical for battery preservation
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_OFF);
  delay(100);

  _active = false;
  Serial.println(F("[AP] SoftAP & Captive Portal stopped, WiFi radio OFF"));
}

void localApUpdate() {
  if (!_active) return;

  // Process DNS queries for captive portal automatic redirection
  _dnsServer.processNextRequest();

  // Process HTTP client requests
  _httpServer.handleClient();

  // Process WebSocket events and packets
  _wsServer.loop();
}

bool localApIsActive() {
  return _active;
}

void localApSendGPS(float lat, float lon, uint8_t satellites, bool hasFix) {
  if (!_active) return;

  // Broadcast GPS update to all connected WebSocket clients
  char buf[128];
  snprintf(buf, sizeof(buf),
    "{\"type\":\"gps\",\"lat\":%.6f,\"lon\":%.6f,\"sats\":%u,\"fix\":%s}",
    lat, lon, satellites, hasFix ? "true" : "false");

  _wsServer.broadcastTXT(buf);
}

void localApSendTelemetry(float ax, float ay, float az,
                          float gx, float gy, float gz,
                          float aMag, uint8_t fsmState) {
  if (!_active) return;

  // Broadcast IMU + FSM at ~20Hz
  char buf[200];
  snprintf(buf, sizeof(buf),
    "{\"type\":\"tel\",\"ax\":%.3f,\"ay\":%.3f,\"az\":%.3f,"
    "\"gx\":%.1f,\"gy\":%.1f,\"gz\":%.1f,"
    "\"am\":%.3f,\"fsm\":%u}",
    ax, ay, az, gx, gy, gz, aMag, fsmState);

  _wsServer.broadcastTXT(buf);
}
