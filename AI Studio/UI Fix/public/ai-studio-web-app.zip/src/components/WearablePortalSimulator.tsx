import React, { useState, useEffect, useRef } from 'react';
import { 
  Wifi, 
  Activity, 
  MapPin, 
  ShieldAlert, 
  Smartphone, 
  Monitor, 
  RefreshCw, 
  AlertTriangle, 
  CheckCircle2, 
  Play, 
  Pause, 
  Layers,
  ArrowRight,
  ExternalLink,
  Code2,
  Check,
  ShieldCheck,
  Compass,
  HelpCircle,
  Sparkles,
  X,
  ChevronRight,
  ChevronLeft,
  Info
} from 'lucide-react';

type WearablePage = 'setup' | 'telemetry' | 'map';

interface TutorialStep {
  step: number;
  title: string;
  badge: string;
  target: 'softap' | 'user-name' | 'photo-link' | 'register-btn' | 'navigation';
  description: string;
  actionHint: string;
  tab: WearablePage;
}

const TUTORIAL_STEPS: TutorialStep[] = [
  {
    step: 1,
    title: '1. Connect to Your Device’s Wi-Fi',
    badge: 'STEP 1: GET CONNECTED',
    target: 'softap',
    description: 'Turn on your wearable safety device. On your phone, tablet, or laptop, open your Wi-Fi settings and choose the network named "RAMS-WEARABLE". This setup screen will open up right on your screen.',
    actionHint: 'Look for the status badge at the top. When it turns green and says "ONLINE", you are ready to continue.',
    tab: 'setup'
  },
  {
    step: 2,
    title: '2. Type Your Full Name',
    badge: 'STEP 2: ROAD USER PROFILE',
    target: 'user-name',
    description: 'Type your name (or the name of the person carrying this device). This system protects everyone on the road—pedestrians walking on the street, people on bicycles, daily commuters, and motorcycle riders. If you ever have a fall or collision, emergency responders will instantly see who you are so they can help you right away.',
    actionHint: 'Type your full name into the name box.',
    tab: 'setup'
  },
  {
    step: 3,
    title: '3. Add Your Photo',
    badge: 'STEP 3: IDENTIFICATION PHOTO',
    target: 'photo-link',
    description: 'Paste a shareable link to your photo from Google Drive. Having your picture attached helps rescue teams and barangay health responders quickly recognize you in an emergency.',
    actionHint: 'Paste your link, and you will see your photo preview appear in the card below.',
    tab: 'setup'
  },
  {
    step: 4,
    title: '4. Save Your Information',
    badge: 'STEP 4: SAVE TO DEVICE',
    target: 'register-btn',
    description: 'Click the "SAVE & REGISTER DEVICE" button. This securely stores your name and photo inside the wearable device so you only need to set it up once. Your details will stay safe even when the device is turned off or recharging.',
    actionHint: 'Tap the white "SAVE & REGISTER DEVICE" button to finish saving.',
    tab: 'setup'
  },
  {
    step: 5,
    title: '5. You Are Protected & Ready to Go!',
    badge: 'STEP 5: READY & MONITORING',
    target: 'navigation',
    description: 'Great job! Your wearable device is now actively watching out for you. It automatically senses sudden falls, hard impacts, and when someone cannot get up. You can tap "Live Sensors" to see your movement in real time, or tap "Radar" to see your location on the map.',
    actionHint: 'Use the bottom buttons anytime to check on your live sensors or radar location.',
    tab: 'telemetry'
  }
];

export const WearablePortalSimulator: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<WearablePage>('telemetry');
  const [deviceMode, setDeviceMode] = useState<'mobile' | 'desktop'>('mobile');
  const [showComparison, setShowComparison] = useState<boolean>(false);
  const [wsConnected, setWsConnected] = useState<boolean>(true);
  const [isStreaming, setIsStreaming] = useState<boolean>(true);

  // Tutorial Tour State
  const [isTutorialActive, setIsTutorialActive] = useState<boolean>(false);
  const [tutorialStep, setTutorialStep] = useState<number>(0);

  // Simulated Sensor & Device Data
  const [fsmState, setFsmState] = useState<number>(0); // 0=Idle, 1=Freefall, 2=Impact, 3=Stillness, 4=Emergency
  const [userName, setUserName] = useState<string>('Juan Dela Cruz');
  const [driveLink, setDriveLink] = useState<string>('https://drive.google.com/file/d/1A2B3C4D5E6F7G/view?usp=sharing');
  const [regStatus, setRegStatus] = useState<string | null>(null);

  // Telemetry values
  const [accel, setAccel] = useState({ x: 0.04, y: -0.02, z: 0.99, mag: 1.00 });
  const [gyro, setGyro] = useState({ x: 1.2, y: -0.8, z: 0.4 });
  const [gps, setGps] = useState({ lat: 17.6132, lon: 121.7269, sats: 9, hasFix: true });
  const [emergencyCountdown, setEmergencyCountdown] = useState<number | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const historyRef = useRef<Array<[number, number, number]>>([]);

  // FSM Names mapping
  const fsmNames = [
    '0: IDLE (ARMED)',
    '1: FREEFALL DETECTED',
    '2: IMPACT SPIKE',
    '3: STILLNESS VERIFY',
    '4: EMERGENCY ALARM'
  ];

  // Continuous telemetry stream simulation
  useEffect(() => {
    if (!isStreaming || !wsConnected) return;

    const interval = setInterval(() => {
      setAccel((prev) => {
        let nx = prev.x;
        let ny = prev.y;
        let nz = prev.z;

        if (fsmState === 0) {
          // Normal micro-vibrations
          nx = (Math.random() - 0.5) * 0.12;
          ny = (Math.random() - 0.5) * 0.12;
          nz = 0.98 + (Math.random() - 0.5) * 0.08;
        } else if (fsmState === 1) {
          // Freefall: acceleration drops to near 0
          nx = (Math.random() - 0.5) * 0.08;
          ny = (Math.random() - 0.5) * 0.08;
          nz = 0.18 + (Math.random() - 0.5) * 0.08;
        } else if (fsmState === 2) {
          // High Impact spike
          nx = 2.4 + (Math.random() - 0.5) * 1.0;
          ny = 3.1 + (Math.random() - 0.5) * 0.8;
          nz = 4.2 + (Math.random() - 0.5) * 1.5;
        } else if (fsmState === 3 || fsmState === 4) {
          // Stillness
          nx = 0.01;
          ny = 0.02;
          nz = 0.99;
        }

        const mag = Math.sqrt(nx * nx + ny * ny + nz * nz);
        historyRef.current.push([nx, ny, nz]);
        if (historyRef.current.length > 100) {
          historyRef.current.shift();
        }
        return { x: nx, y: ny, z: nz, mag };
      });

      setGyro(() => ({
        x: (Math.random() - 0.5) * 4,
        y: (Math.random() - 0.5) * 4,
        z: (Math.random() - 0.5) * 3,
      }));
    }, 100);

    return () => clearInterval(interval);
  }, [isStreaming, wsConnected, fsmState]);

  // Emergency countdown timer
  useEffect(() => {
    if (fsmState === 4) {
      setEmergencyCountdown(10);
      const timer = setInterval(() => {
        setEmergencyCountdown((c) => {
          if (c === null || c <= 1) {
            clearInterval(timer);
            return 0;
          }
          return c - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    } else {
      setEmergencyCountdown(null);
    }
  }, [fsmState]);

  // Waveform canvas drawing
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.fillStyle = '#09090b';
    ctx.fillRect(0, 0, w, h);

    // Center 0g baseline
    ctx.strokeStyle = '#27272a';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, h / 2);
    ctx.lineTo(w, h / 2);
    ctx.stroke();

    const data = historyRef.current;
    if (data.length < 2) return;

    const step = w / 100;
    const colors = ['#f87171', '#34d399', '#60a5fa']; // X: Red, Y: Green, Z: Blue

    for (let axis = 0; axis < 3; axis++) {
      ctx.strokeStyle = colors[axis];
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let i = 0; i < data.length; i++) {
        const x = i * step;
        const val = data[i][axis];
        // Scale -4g to +4g into canvas height
        let y = h / 2 - val * (h / 8);
        if (y < 2) y = 2;
        if (y > h - 2) y = h - 2;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
  }, [accel]);

  const handleSimulateFall = () => {
    setFsmState(1); // Freefall
    setTimeout(() => {
      setFsmState(2); // Impact
      setTimeout(() => {
        setFsmState(3); // Stillness
        setTimeout(() => {
          setFsmState(4); // Confirmed alarm
        }, 1500);
      }, 1000);
    }, 800);
  };

  const handleResetFsm = () => {
    setFsmState(0);
    setEmergencyCountdown(null);
  };

  const handleMockRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setRegStatus('registering');
    setTimeout(() => {
      setRegStatus('success');
    }, 600);
  };

  return (
    <div className="space-y-6" id="wearable-portal-stage">
      {/* Top Banner & Control Deck */}
      <div className="rounded-xl border border-neutral-800 bg-neutral-900/90 p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg border border-neutral-700 bg-neutral-950 text-white">
                <Wifi className="h-4 w-4" />
              </span>
              <h2 className="text-sm sm:text-base font-black tracking-tight text-white uppercase">
                Wearable Captive Portal & WebSocket Live Console
              </h2>
              <span className="px-2 py-0.5 rounded border border-neutral-700 bg-neutral-950 text-[10px] font-mono font-bold text-neutral-300 uppercase tracking-wider">
                ESP32 SoftAP 192.168.4.1
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-1.5 leading-relaxed font-medium max-w-3xl">
              Production simulator for the Wearable ESP32 LittleFS captive portal and WebSocket telemetry server (Port 81).
              Redesigned with the backend design rules: monochromatic slate surfaces, high-contrast Plus Jakarta Sans & JetBrains Mono typography, and zero artificial gradients.
            </p>
          </div>

          {/* Mode Switchers */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setShowComparison(!showComparison)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider border transition-colors cursor-pointer ${
                showComparison
                  ? 'bg-white text-neutral-950 border-white shadow-xs'
                  : 'bg-neutral-950 hover:bg-neutral-800 text-neutral-300 border-neutral-700'
              }`}
            >
              <Layers className="h-3.5 w-3.5" />
              <span>{showComparison ? 'Hide Design Matrix' : 'Design System Matrix'}</span>
            </button>

            <div className="flex items-center bg-neutral-950 p-1 rounded-lg border border-neutral-800">
              <button
                onClick={() => setDeviceMode('mobile')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-mono font-bold uppercase tracking-wider transition-colors cursor-pointer ${
                  deviceMode === 'mobile'
                    ? 'bg-white text-neutral-950 shadow-xs'
                    : 'text-neutral-400 hover:text-white'
                }`}
                title="Mobile Phone Viewport"
              >
                <Smartphone className="h-3.5 w-3.5" />
                <span>Mobile</span>
              </button>
              <button
                onClick={() => setDeviceMode('desktop')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-mono font-bold uppercase tracking-wider transition-colors cursor-pointer ${
                  deviceMode === 'desktop'
                    ? 'bg-white text-neutral-950 shadow-xs'
                    : 'text-neutral-400 hover:text-white'
                }`}
                title="Widescreen Viewport"
              >
                <Monitor className="h-3.5 w-3.5" />
                <span>Widescreen</span>
              </button>
            </div>

            <button
              onClick={() => {
                setCurrentPage('setup');
                setTutorialStep(0);
                setIsTutorialActive(true);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider bg-white hover:bg-neutral-200 text-neutral-950 shadow-xs transition-colors cursor-pointer"
              title="Launch Interface Tutorial Tour for Setup"
            >
              <HelpCircle className="h-3.5 w-3.5" />
              <span>Setup Tutorial</span>
            </button>
          </div>
        </div>

        {/* Live WebSocket Test Bar */}
        <div className="mt-4 pt-3.5 border-t border-neutral-800 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="text-neutral-500 font-bold text-[10px] uppercase tracking-wider">HARDWARE WS BRIDGE:</span>
            
            <button
              onClick={() => setWsConnected(!wsConnected)}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded border text-[11px] font-bold uppercase tracking-wider transition-colors cursor-pointer ${
                wsConnected
                  ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
                  : 'bg-rose-950/60 text-rose-300 border-rose-800'
              }`}
            >
              <span className={`h-1.5 w-1.5 rounded-full ${wsConnected ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500'}`}></span>
              <span>{wsConnected ? 'PORT 81: CONNECTED' : 'WS: DISCONNECTED'}</span>
            </button>

            <button
              onClick={() => setIsStreaming(!isStreaming)}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded border border-neutral-700 bg-neutral-950 hover:bg-neutral-800 text-neutral-200 text-[11px] font-bold uppercase tracking-wider cursor-pointer transition-colors"
            >
              {isStreaming ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
              <span>{isStreaming ? 'STREAM 100HZ' : 'PAUSED'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSimulateFall}
              disabled={fsmState !== 0}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-950/80 hover:bg-rose-900 border border-rose-800 text-rose-200 font-mono font-bold text-[11px] uppercase tracking-wider transition-colors disabled:opacity-40 cursor-pointer shadow-xs"
            >
              <AlertTriangle className="h-3 w-3 text-rose-400" />
              <span>Simulate Crash Event</span>
            </button>

            <button
              onClick={handleResetFsm}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-neutral-700 bg-neutral-950 hover:bg-neutral-800 text-neutral-300 font-mono font-bold text-[11px] uppercase tracking-wider transition-colors cursor-pointer"
            >
              <RefreshCw className="h-3 w-3" />
              <span>Reset State</span>
            </button>
          </div>
        </div>
      </div>

      {/* Design System Matrix Comparison (Collapsible) */}
      {showComparison && (
        <div className="rounded-xl border border-neutral-800 bg-neutral-900/95 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-neutral-800">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-emerald-400" />
              <h3 className="font-black text-xs uppercase tracking-tight text-white">
                Design System Aesthetic Parity: Receiver Portal • Wearable Portal • Backend Dashboard
              </h3>
            </div>
            <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded border border-neutral-700 bg-neutral-950 text-neutral-300 uppercase tracking-wider">
              Monochrome Token Parity
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
            {/* Receiver Token */}
            <div className="p-3.5 rounded-lg bg-neutral-950 border border-neutral-800">
              <div className="text-[10px] font-bold text-white mb-2 uppercase flex items-center justify-between pb-1 border-b border-neutral-800">
                <span>Receiver Captive Portal</span>
                <span className="text-neutral-500 font-normal">receiver/data</span>
              </div>
              <ul className="space-y-1 text-neutral-400 text-[11px]">
                <li><span className="text-neutral-500">CANVAS:</span> <code className="text-white">#09090B</code> Deep Ink</li>
                <li><span className="text-neutral-500">SURFACE:</span> <code className="text-white">#18181B</code> Surface</li>
                <li><span className="text-neutral-500">BORDER:</span> <code className="text-white">1px solid #27272A</code></li>
                <li><span className="text-neutral-500">TYPOGRAPHY:</span> Jakarta Sans 900</li>
                <li><span className="text-neutral-500">ACTION BTN:</span> High-Contrast White</li>
              </ul>
            </div>

            {/* Wearable Token */}
            <div className="p-3.5 rounded-lg bg-neutral-950 border border-neutral-700 relative">
              <div className="text-[10px] font-bold text-white mb-2 uppercase flex items-center justify-between pb-1 border-b border-neutral-800">
                <span>Wearable Portal (Redesigned)</span>
                <span className="text-emerald-400 font-bold">100% MATCH</span>
              </div>
              <ul className="space-y-1 text-neutral-400 text-[11px]">
                <li><span className="text-neutral-500">CANVAS:</span> <code className="text-white">#09090B</code> Deep Ink</li>
                <li><span className="text-neutral-500">SURFACE:</span> <code className="text-white">#18181B</code> Surface</li>
                <li><span className="text-neutral-500">BORDER:</span> <code className="text-white">1px solid #27272A</code></li>
                <li><span className="text-neutral-500">TYPOGRAPHY:</span> JetBrains Mono 700</li>
                <li><span className="text-neutral-500">ACTION BTN:</span> High-Contrast White</li>
              </ul>
            </div>

            {/* Backend Token */}
            <div className="p-3.5 rounded-lg bg-neutral-950 border border-neutral-800">
              <div className="text-[10px] font-bold text-white mb-2 uppercase flex items-center justify-between pb-1 border-b border-neutral-800">
                <span>Netlify Backend Dashboard</span>
                <span className="text-neutral-500 font-normal">backend/src</span>
              </div>
              <ul className="space-y-1 text-neutral-400 text-[11px]">
                <li><span className="text-neutral-500">CANVAS:</span> <code className="text-white">#09090B</code> Neutral-950</li>
                <li><span className="text-neutral-500">SURFACE:</span> <code className="text-white">#18181B</code> Neutral-900</li>
                <li><span className="text-neutral-500">BORDER:</span> <code className="text-white">1px solid #27272A</code></li>
                <li><span className="text-neutral-500">RULES:</span> No AI Slop / No Gradients</li>
                <li><span className="text-neutral-500">GRID:</span> 8pt Strict Geometry</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Main Interactive Stage */}
      <div className="flex justify-center">
        <div
          className={`transition-all duration-300 w-full ${
            deviceMode === 'mobile' ? 'max-w-[430px]' : 'max-w-[640px]'
          }`}
        >
          {/* Simulated Device Frame Header */}
          <div className="bg-neutral-950 text-neutral-300 rounded-t-xl px-4 py-2.5 border-x border-t border-neutral-800 flex items-center justify-between text-xs font-mono">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="font-bold text-white text-[11px] uppercase tracking-wider">RAMS-WEARABLE</span>
              <span className="text-neutral-500 text-[10px]">192.168.4.1</span>
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">Captive Portal</span>
          </div>

          {/* Device Screen Body (Strict Backend Monochrome Minimalist Aesthetic) */}
          <div className="bg-[#09090b] text-[#f4f4f5] p-4 sm:p-5 border border-neutral-800 rounded-b-xl shadow-2xl font-sans min-h-[580px] flex flex-col justify-between">
            {/* Unified Card Container (No nested cards) */}
            <div className="w-full">
              {/* Brand Header */}
              <div className="flex items-center gap-3 pb-3 mb-3.5 border-b border-neutral-800">
                <div className="w-9 h-9 rounded-lg border border-neutral-700 bg-black flex items-center justify-center overflow-hidden p-0.5 shrink-0">
                  <img
                    src="/logo.jpg"
                    alt="RAMS Logo"
                    className="w-full h-full object-contain rounded"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                </div>
                <div>
                  <h1 className="text-xs font-black uppercase tracking-tight text-white leading-tight">
                    ROAD ACCIDENT MONITORING SYSTEM
                  </h1>
                  <p className="text-[10px] font-mono font-bold uppercase tracking-wider text-neutral-400 mt-0.5">
                    WEARABLE ESP32 • {currentPage.toUpperCase()} MODE
                  </p>
                </div>
              </div>

              {/* WebSocket Status Pill (Single-line Atomic Badge) */}
              <div className={`mb-3.5 transition-all duration-300 ${
                isTutorialActive && TUTORIAL_STEPS[tutorialStep].target === 'softap'
                  ? 'relative z-50 ring-4 ring-white shadow-[0_0_30px_rgba(255,255,255,0.45)] rounded-full'
                  : ''
              }`}>
                <div
                  className={`flex items-center justify-center gap-2 py-1.5 px-3 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider border transition-colors ${
                    wsConnected
                      ? 'bg-neutral-900 text-emerald-400 border-emerald-900/60'
                      : 'bg-neutral-900 text-rose-400 border-rose-900/60'
                  }`}
                >
                  <span
                    className={`h-1.5 w-1.5 rounded-full ${
                      wsConnected ? 'bg-emerald-400' : 'bg-rose-500'
                    }`}
                  ></span>
                  <span>{wsConnected ? 'WEBSOCKET: LIVE STREAM (PORT 81)' : 'WEBSOCKET: DISCONNECTED'}</span>
                </div>
              </div>

              {/* Emergency Alert Banner (Shown if FSM is in state 4) */}
              {fsmState === 4 && (
                <div className="mb-3.5 p-3 rounded-lg bg-rose-950/70 border border-rose-700 text-white">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <ShieldAlert className="h-4 w-4 text-rose-400 shrink-0 animate-bounce" />
                      <div>
                        <div className="font-mono font-bold text-[11px] uppercase tracking-wider text-white">
                          CRASH DETECTED • BUZZER ACTIVE
                        </div>
                        <div className="text-[10px] font-mono text-neutral-300">
                          Broadcasting LoRa packet in {emergencyCountdown}s
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={handleResetFsm}
                      className="px-2.5 py-1 rounded bg-white text-neutral-950 hover:bg-neutral-200 font-mono font-black text-[10px] uppercase tracking-wider transition-colors cursor-pointer shrink-0"
                    >
                      CANCEL
                    </button>
                  </div>
                </div>
              )}

              {/* VIEW 1: REGISTRATION & SETUP */}
              {currentPage === 'setup' && (
                <div className="space-y-3">
                  {/* Setup Sequence Cloud Banner */}
                  <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 relative space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="p-1 rounded-md bg-neutral-900 border border-neutral-700 text-amber-400">
                          <Sparkles className="h-3 w-3" />
                        </span>
                        <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-white">
                          Easy Setup Guide (For All Road Users)
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setTutorialStep(0);
                          setIsTutorialActive(true);
                        }}
                        className="inline-flex items-center gap-1 text-[10px] font-mono font-bold uppercase tracking-wider text-neutral-300 hover:text-white underline cursor-pointer"
                      >
                        <span>Start Easy Tour</span>
                        <ChevronRight className="h-3 w-3" />
                      </button>
                    </div>
                    <p className="text-[11px] text-neutral-400 font-medium leading-relaxed">
                      Follow 4 simple steps: <strong className="text-white">1)</strong> Connect to device Wi-Fi, <strong className="text-white">2)</strong> Enter your name (walking, cycling, or riding), <strong className="text-white">3)</strong> Add your photo link, and <strong className="text-white">4)</strong> Save to device.
                    </p>
                  </div>

                  <form onSubmit={handleMockRegister} className="space-y-3">
                    <div className={`transition-all duration-300 rounded-lg ${
                      isTutorialActive && TUTORIAL_STEPS[tutorialStep].target === 'user-name'
                        ? 'relative z-50 ring-4 ring-white shadow-[0_0_30px_rgba(255,255,255,0.45)] bg-neutral-950 p-2'
                        : ''
                    }`}>
                      <label className="block text-[10px] font-mono font-bold uppercase tracking-wider text-neutral-400 mb-1">
                        Road User Full Name (Pedestrian, Cyclist, or Driver)
                      </label>
                      <input
                        type="text"
                        value={userName}
                        onChange={(e) => setUserName(e.target.value)}
                        placeholder="e.g. Maria Santos (Walking / Cycling / Riding)"
                        className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-lg text-xs text-white font-mono outline-none focus:border-white transition-colors"
                        required
                      />
                    </div>

                    <div className={`transition-all duration-300 rounded-lg space-y-2 ${
                      isTutorialActive && TUTORIAL_STEPS[tutorialStep].target === 'photo-link'
                        ? 'relative z-50 ring-4 ring-white shadow-[0_0_30px_rgba(255,255,255,0.45)] bg-neutral-950 p-2'
                        : ''
                    }`}>
                      <div>
                        <label className="block text-[10px] font-mono font-bold uppercase tracking-wider text-neutral-400 mb-1">
                          ID Photo (Google Drive Share Link)
                        </label>
                        <input
                          type="url"
                          value={driveLink}
                          onChange={(e) => setDriveLink(e.target.value)}
                          placeholder="https://drive.google.com/file/d/.../view"
                          className="w-full px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-lg text-xs text-white font-mono outline-none focus:border-white transition-colors"
                          required
                        />
                      </div>

                      {/* Photo preview info */}
                      <div className="flex items-center gap-2.5 p-2.5 rounded-lg bg-neutral-900 border border-neutral-800">
                        <div className="w-10 h-10 rounded border border-neutral-700 bg-black flex items-center justify-center overflow-hidden shrink-0">
                          <img
                            src="/logo.jpg"
                            alt="Thumbnail preview"
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLElement).style.display = 'none';
                            }}
                          />
                        </div>
                        <div className="text-[10px] font-mono text-neutral-400 leading-snug">
                          <span className="text-white font-bold block">{userName || 'Your Name'}</span>
                          <span>Emergency photo attached</span>
                        </div>
                      </div>
                    </div>

                    {/* High-Contrast Action Button (White on Dark, NO Gradients) */}
                    <button
                      type="submit"
                      disabled={!wsConnected}
                      className={`w-full py-2 px-4 rounded-lg bg-white hover:bg-neutral-200 text-neutral-950 font-mono font-black text-xs uppercase tracking-wider shadow-xs transition-all cursor-pointer disabled:opacity-40 ${
                        isTutorialActive && TUTORIAL_STEPS[tutorialStep].target === 'register-btn'
                          ? 'relative z-50 ring-4 ring-white shadow-[0_0_30px_rgba(255,255,255,0.45)] scale-[1.02]'
                          : ''
                      }`}
                    >
                      {regStatus === 'registering' ? 'SAVING PROFILE...' : 'SAVE & REGISTER DEVICE'}
                    </button>
                  </form>

                  {regStatus === 'success' && (
                    <div className="p-2.5 rounded-lg bg-emerald-950/60 border border-emerald-800 text-emerald-300 font-mono text-center text-[10px] font-bold uppercase tracking-wider">
                      ✓ PROFILE SAVED • READY TO PROTECT ROAD USER
                    </div>
                  )}
                </div>
              )}

              {/* VIEW 2: LIVE TELEMETRY */}
              {currentPage === 'telemetry' && (
                <div className="space-y-2.5">
                  {/* FSM State & Peak Magnitude */}
                  <div className="grid grid-cols-2 gap-2">
                    <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-2 text-center">
                      <div className="text-[9px] font-mono font-bold uppercase tracking-wider text-neutral-400">
                        FSM Detection State
                      </div>
                      <div
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-mono font-black uppercase mt-1 border ${
                          fsmState === 0
                            ? 'bg-neutral-950 text-white border-neutral-700'
                            : fsmState === 1
                            ? 'bg-amber-950/60 text-amber-300 border-amber-800'
                            : fsmState === 2
                            ? 'bg-rose-950/60 text-rose-300 border-rose-800'
                            : fsmState === 3
                            ? 'bg-neutral-950 text-purple-300 border-purple-800'
                            : 'bg-rose-600 text-white border-rose-500'
                        }`}
                      >
                        {fsmNames[fsmState]}
                      </div>
                    </div>

                    <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-2 text-center">
                      <div className="text-[9px] font-mono font-bold uppercase tracking-wider text-neutral-400">
                        Total Vector Accel (|A|)
                      </div>
                      <div className="font-mono text-sm font-black text-white mt-0.5">
                        {accel.mag.toFixed(3)} g
                      </div>
                    </div>
                  </div>

                  {/* 3-Axis Accel */}
                  <div className="grid grid-cols-3 gap-2">
                    <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-2 text-center">
                      <div className="text-[9px] font-mono font-bold uppercase tracking-wider text-[#f87171]">Ax (X-Axis)</div>
                      <div className="font-mono text-xs font-bold text-white mt-0.5">{accel.x.toFixed(2)} g</div>
                    </div>
                    <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-2 text-center">
                      <div className="text-[9px] font-mono font-bold uppercase tracking-wider text-[#34d399]">Ay (Y-Axis)</div>
                      <div className="font-mono text-xs font-bold text-white mt-0.5">{accel.y.toFixed(2)} g</div>
                    </div>
                    <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-2 text-center">
                      <div className="text-[9px] font-mono font-bold uppercase tracking-wider text-[#60a5fa]">Az (Z-Axis)</div>
                      <div className="font-mono text-xs font-bold text-white mt-0.5">{accel.z.toFixed(2)} g</div>
                    </div>
                  </div>

                  {/* Live Waveform Canvas */}
                  <div>
                    <div className="flex justify-between items-center text-[9px] font-mono uppercase tracking-wider text-neutral-400 mb-1">
                      <span>Accel Waveform (X=Red, Y=Green, Z=Blue)</span>
                      <span className="text-emerald-400 font-bold">100Hz • ±8g Range</span>
                    </div>
                    <canvas
                      ref={canvasRef}
                      width={480}
                      height={96}
                      className="w-full h-22 bg-[#09090b] border border-neutral-800 rounded-lg block"
                    />
                  </div>

                  {/* Gyroscope Readings */}
                  <div className="grid grid-cols-3 gap-2">
                    <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-1.5 text-center">
                      <div className="text-[8px] font-mono font-bold uppercase tracking-wider text-neutral-400">Gyro X</div>
                      <div className="font-mono text-xs font-bold text-white mt-0.5">{gyro.x.toFixed(1)} °/s</div>
                    </div>
                    <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-1.5 text-center">
                      <div className="text-[8px] font-mono font-bold uppercase tracking-wider text-neutral-400">Gyro Y</div>
                      <div className="font-mono text-xs font-bold text-white mt-0.5">{gyro.y.toFixed(1)} °/s</div>
                    </div>
                    <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-1.5 text-center">
                      <div className="text-[8px] font-mono font-bold uppercase tracking-wider text-neutral-400">Gyro Z</div>
                      <div className="font-mono text-xs font-bold text-white mt-0.5">{gyro.z.toFixed(1)} °/s</div>
                    </div>
                  </div>

                  {/* GPS Coordinates */}
                  <div className="grid grid-cols-3 gap-2">
                    <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-1.5 text-center">
                      <div className="text-[8px] font-mono font-bold uppercase tracking-wider text-neutral-400">Latitude</div>
                      <div className="font-mono text-xs font-bold text-white mt-0.5">{gps.lat.toFixed(4)}°</div>
                    </div>
                    <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-1.5 text-center">
                      <div className="text-[8px] font-mono font-bold uppercase tracking-wider text-neutral-400">Longitude</div>
                      <div className="font-mono text-xs font-bold text-white mt-0.5">{gps.lon.toFixed(4)}°</div>
                    </div>
                    <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-1.5 text-center">
                      <div className="text-[8px] font-mono font-bold uppercase tracking-wider text-neutral-400">GPS Status</div>
                      <div className="font-mono text-xs font-bold text-emerald-400 mt-0.5">{gps.sats} Sats (3D)</div>
                    </div>
                  </div>
                </div>
              )}

              {/* VIEW 3: OFFLINE RADAR MAP */}
              {currentPage === 'map' && (
                <div className="space-y-2.5">
                  <div className="relative w-full h-52 bg-neutral-900 border border-neutral-800 rounded-lg overflow-hidden flex items-center justify-center">
                    {/* Concentric Vector Radar Rings */}
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                      <div className="w-44 h-44 rounded-full border border-neutral-800"></div>
                      <div className="w-30 h-30 rounded-full border border-neutral-800/80"></div>
                      <div className="w-16 h-16 rounded-full border border-neutral-800/60"></div>
                      <div className="absolute w-full h-[1px] bg-neutral-800/70"></div>
                      <div className="absolute h-full w-[1px] bg-neutral-800/70"></div>
                    </div>

                    {/* GPS Position Pin */}
                    <div className="relative z-10 flex flex-col items-center">
                      <div className="relative">
                        <div className="h-3 w-3 rounded-full bg-rose-500 border border-white"></div>
                        <div className="absolute -inset-1.5 rounded-full border border-rose-500/50 animate-ping"></div>
                      </div>
                      <span className="mt-2 text-[9px] font-mono font-bold bg-neutral-950 text-white px-2 py-0.5 rounded border border-neutral-700 uppercase tracking-wider">
                        USER LOCATION
                      </span>
                    </div>

                    {/* Coordinate Overlay */}
                    <div className="absolute top-2 left-2 bg-neutral-950/90 px-2 py-0.5 rounded text-[9px] font-mono text-neutral-300 border border-neutral-800">
                      Tuguegarao Sector 17°N
                    </div>
                  </div>

                  <div className="flex justify-between items-center text-[10px] font-mono text-neutral-400 px-1">
                    <span>LAT: {gps.lat.toFixed(6)}  LON: {gps.lon.toFixed(6)}</span>
                    <span className="text-emerald-400 font-bold uppercase">{gps.sats} SATELLITES (LOCKED)</span>
                  </div>
                </div>
              )}

              {/* Navigation Tabs (8pt Grid High-Contrast Capsule Bar) */}
              <div className={`flex gap-1.5 mt-4 pt-3.5 border-t border-neutral-800 transition-all duration-300 ${
                isTutorialActive && TUTORIAL_STEPS[tutorialStep].target === 'navigation'
                  ? 'relative z-50 ring-4 ring-white shadow-[0_0_30px_rgba(255,255,255,0.45)] p-1.5 bg-neutral-950 rounded-lg'
                  : ''
              }`}>
                <button
                  onClick={() => setCurrentPage('setup')}
                  className={`flex-1 py-1.5 px-1 text-center font-mono text-[10px] font-bold uppercase tracking-wider rounded-md border transition-colors cursor-pointer ${
                    currentPage === 'setup'
                      ? 'bg-white text-neutral-950 border-white shadow-xs font-black'
                      : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white border-neutral-800'
                  }`}
                >
                  SETUP
                </button>
                <button
                  onClick={() => setCurrentPage('telemetry')}
                  className={`flex-1 py-1.5 px-1 text-center font-mono text-[10px] font-bold uppercase tracking-wider rounded-md border transition-colors cursor-pointer ${
                    currentPage === 'telemetry'
                      ? 'bg-white text-neutral-950 border-white shadow-xs font-black'
                      : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white border-neutral-800'
                  }`}
                >
                  TELEMETRY
                </button>
                <button
                  onClick={() => setCurrentPage('map')}
                  className={`flex-1 py-1.5 px-1 text-center font-mono text-[10px] font-bold uppercase tracking-wider rounded-md border transition-colors cursor-pointer ${
                    currentPage === 'map'
                      ? 'bg-white text-neutral-950 border-white shadow-xs font-black'
                      : 'bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white border-neutral-800'
                  }`}
                >
                  OFFLINE MAP
                </button>
              </div>
            </div>

            {/* Captive Portal Bottom Label */}
            <div className="text-center text-[10px] font-mono uppercase tracking-wider text-neutral-600 mt-4 pt-2 border-t border-neutral-800/60">
              Autonomous ESP32 SoftAP • Flash LittleFS Storage
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Setup Tutorial Cloud & Backdrop Blur */}
      {isTutorialActive && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 pointer-events-auto">
          {/* Background Blur Overlay */}
          <div 
            className="fixed inset-0 bg-black/80 backdrop-blur-md transition-opacity duration-300"
            onClick={() => setIsTutorialActive(false)}
          />

          {/* Cloud for Text Speech-Bubble Dialog */}
          <div className="relative z-50 w-full max-w-lg bg-[#141417] border-2 border-neutral-600 rounded-3xl p-6 sm:p-7 shadow-[0_25px_60px_rgba(0,0,0,0.95)] text-white">
            {/* Top Cloud Header */}
            <div className="flex items-center justify-between gap-3 pb-3.5 border-b border-neutral-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-neutral-900 border border-neutral-700 text-amber-400">
                  <Sparkles className="h-4 w-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-400">
                      EASY SETUP GUIDE
                    </span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300">
                      {TUTORIAL_STEPS[tutorialStep].badge}
                    </span>
                  </div>
                  <span className="text-xs font-mono font-bold text-white">
                    Step {TUTORIAL_STEPS[tutorialStep].step} of {TUTORIAL_STEPS.length}
                  </span>
                </div>
              </div>

              <button
                onClick={() => setIsTutorialActive(false)}
                className="p-1.5 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors cursor-pointer"
                title="Exit Tutorial"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Step Instructional Body */}
            <div className="mt-4 space-y-3.5">
              <h3 className="text-base sm:text-lg font-black uppercase tracking-tight text-white flex items-center gap-2">
                <span>{TUTORIAL_STEPS[tutorialStep].title}</span>
              </h3>
              <p className="text-xs text-neutral-300 font-medium leading-relaxed">
                {TUTORIAL_STEPS[tutorialStep].description}
              </p>

              {/* Action Prompt Callout */}
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-neutral-900/90 border border-neutral-800 text-xs font-mono text-neutral-200">
                <Info className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-emerald-400 uppercase tracking-wider text-[10px] block mb-0.5">Quick Action:</strong>
                  {TUTORIAL_STEPS[tutorialStep].actionHint}
                </div>
              </div>
            </div>

            {/* Footer Navigation & Step Indicators */}
            <div className="mt-6 pt-4 border-t border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              {/* Step dots */}
              <div className="flex items-center gap-1.5">
                {TUTORIAL_STEPS.map((stepItem, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setTutorialStep(idx);
                      setCurrentPage(stepItem.tab);
                    }}
                    className={`h-2 rounded-full transition-all cursor-pointer ${
                      tutorialStep === idx
                        ? 'w-7 bg-white'
                        : 'w-2 bg-neutral-700 hover:bg-neutral-500'
                    }`}
                    title={`Jump to Step ${idx + 1}: ${stepItem.title}`}
                  />
                ))}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 self-end sm:self-auto">
                <button
                  onClick={() => setIsTutorialActive(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-mono font-bold uppercase tracking-wider text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors cursor-pointer"
                >
                  Skip
                </button>
                
                {tutorialStep > 0 && (
                  <button
                    onClick={() => {
                      const prev = tutorialStep - 1;
                      setTutorialStep(prev);
                      setCurrentPage(TUTORIAL_STEPS[prev].tab);
                    }}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-neutral-700 bg-neutral-900 hover:bg-neutral-800 text-neutral-200 text-xs font-mono font-bold uppercase tracking-wider transition-colors cursor-pointer"
                  >
                    <ChevronLeft className="h-3.5 w-3.5" />
                    <span>Back</span>
                  </button>
                )}

                <button
                  onClick={() => {
                    if (tutorialStep < TUTORIAL_STEPS.length - 1) {
                      const next = tutorialStep + 1;
                      setTutorialStep(next);
                      setCurrentPage(TUTORIAL_STEPS[next].tab);
                    } else {
                      setIsTutorialActive(false);
                    }
                  }}
                  className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-white hover:bg-neutral-200 text-neutral-950 text-xs font-mono font-black uppercase tracking-wider shadow-xs transition-colors cursor-pointer"
                >
                  <span>{tutorialStep === TUTORIAL_STEPS.length - 1 ? 'Done & Protected!' : 'Next Step'}</span>
                  {tutorialStep < TUTORIAL_STEPS.length - 1 && <ChevronRight className="h-3.5 w-3.5" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
